insert into @t(o,t,c)select o.fi_worknoteId,10037,44 from fi_worknote o,@c c where c.t=112 and c.o=o.fi_RegardingIncidentId  

insert into @t(o,t,c)select o.fi_fi_relationshipmanagementauditlogId,10073,57 from fi_fi_relationshipmanagementauditlog o,@c c where c.t=112 and c.o=o.fi_OriginatingIncidentId  

delete from [IncidentBase]   OUTPUT DELETED.[IncidentId], 112    into SubscriptionTrackingDeletedObject (ObjectId, ObjectTypeCode)   where ([IncidentId] = @IncidentId0)