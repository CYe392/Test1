IF EXISTS (select indid from sysindexes where name = 'ndx_fk_fi_regardingtaskid' and id = OBJECT_ID('fi_worknoteBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_regardingtaskid] ON [dbo].[fi_worknoteBase] ([fi_regardingtaskid]) WHERE fi_regardingtaskid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO