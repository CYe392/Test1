IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_beneficiary1id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_beneficiary1id] ON [dbo].[fi_duediligencetrustBase] ([fi_beneficiary1id]) WHERE fi_beneficiary1id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_beneficiary2id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_beneficiary2id] ON [dbo].[fi_duediligencetrustBase] ([fi_beneficiary2id]) WHERE fi_beneficiary2id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_PerfRev_fk_fi_beneficiary3id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_beneficiary3id] ON [dbo].[fi_duediligencetrustBase] ([fi_beneficiary3id]) WHERE fi_beneficiary3id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_beneficiary4id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_beneficiary4id] ON [dbo].[fi_duediligencetrustBase] ([fi_beneficiary4id]) WHERE fi_beneficiary4id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_companydirector1id' and id = OBJECT_ID('fi_duediligencecorpBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_companydirector1id] ON [dbo].[fi_duediligencecorpBase] ([fi_companydirector1id]) WHERE fi_companydirector1id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_companydirector2id' and id = OBJECT_ID('fi_duediligencecorpBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_companydirector2id] ON [dbo].[fi_duediligencecorpBase] ([fi_companydirector2id]) WHERE fi_companydirector2id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_companydirector3id' and id = OBJECT_ID('fi_duediligencecorpBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_companydirector3id] ON [dbo].[fi_duediligencecorpBase] ([fi_companydirector3id]) WHERE fi_companydirector3id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_companydirector4id' and id = OBJECT_ID('fi_duediligencecorpBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_companydirector4id] ON [dbo].[fi_duediligencecorpBase] ([fi_companydirector4id]) WHERE fi_companydirector4id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_companydirector5id' and id = OBJECT_ID('fi_duediligencecorpBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_companydirector5id] ON [dbo].[fi_duediligencecorpBase] ([fi_companydirector5id]) WHERE fi_companydirector5id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_contact' and id = OBJECT_ID('fi_sapphirelogBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_contact] ON [dbo].[fi_sapphirelogBase] ([fi_contact]) WHERE fi_contact IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_contactid' and id = OBJECT_ID('fi_fi_cadextensionattributeauditlogBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_contactid] ON [dbo].[fi_fi_cadextensionattributeauditlogBase] ([fi_contactid]) WHERE fi_contactid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_contactid' and id = OBJECT_ID('fi_fi_financialaccountauditlogBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_contactid] ON [dbo].[fi_fi_financialaccountauditlogBase] ([fi_contactid]) WHERE fi_contactid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_controller1id' and id = OBJECT_ID('fi_duediligencecharityBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_controller1id] ON [dbo].[fi_duediligencecharityBase] ([fi_controller1id]) WHERE fi_controller1id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_controller2id' and id = OBJECT_ID('fi_duediligencecharityBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_controller2id] ON [dbo].[fi_duediligencecharityBase] ([fi_controller2id]) WHERE fi_controller2id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_controller3id' and id = OBJECT_ID('fi_duediligencecharityBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_controller3id] ON [dbo].[fi_duediligencecharityBase] ([fi_controller3id]) WHERE fi_controller3id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_controller4id' and id = OBJECT_ID('fi_duediligencecharityBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_controller4id] ON [dbo].[fi_duediligencecharityBase] ([fi_controller4id]) WHERE fi_controller4id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_customerid' and id = OBJECT_ID('fi_incidentauditlogBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_customerid] ON [dbo].[fi_incidentauditlogBase] ([fi_customerid]) WHERE fi_customerid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_customerid' and id = OBJECT_ID('fi_opportunityauditlogBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_customerid] ON [dbo].[fi_opportunityauditlogBase] ([fi_customerid]) WHERE fi_customerid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_directortrustee1id' and id = OBJECT_ID('fi_duediligencecharityBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_directortrustee1id] ON [dbo].[fi_duediligencecharityBase] ([fi_directortrustee1id]) WHERE fi_directortrustee1id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_directortrustee2id' and id = OBJECT_ID('fi_duediligencecharityBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_directortrustee2id] ON [dbo].[fi_duediligencecharityBase] ([fi_directortrustee2id]) WHERE fi_directortrustee2id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_directortrustee3id' and id = OBJECT_ID('fi_duediligencecharityBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_directortrustee3id] ON [dbo].[fi_duediligencecharityBase] ([fi_directortrustee3id]) WHERE fi_directortrustee3id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_directortrustee4id' and id = OBJECT_ID('fi_duediligencecharityBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_directortrustee4id] ON [dbo].[fi_duediligencecharityBase] ([fi_directortrustee4id]) WHERE fi_directortrustee4id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_individualownercontroller1id' and id = OBJECT_ID('fi_duediligencecorpBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_individualownercontroller1id] ON [dbo].[fi_duediligencecorpBase] ([fi_individualownercontroller1id]) WHERE fi_individualownercontroller1id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_individualownercontroller2id' and id = OBJECT_ID('fi_duediligencecorpBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_individualownercontroller2id] ON [dbo].[fi_duediligencecorpBase] ([fi_individualownercontroller2id]) WHERE fi_individualownercontroller2id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_individualownercontroller3id' and id = OBJECT_ID('fi_duediligencecorpBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_individualownercontroller3id] ON [dbo].[fi_duediligencecorpBase] ([fi_individualownercontroller3id]) WHERE fi_individualownercontroller3id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_individualownercontroller4id' and id = OBJECT_ID('fi_duediligencecorpBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_individualownercontroller4id] ON [dbo].[fi_duediligencecorpBase] ([fi_individualownercontroller4id]) WHERE fi_individualownercontroller4id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_individualownercontroller5id' and id = OBJECT_ID('fi_duediligencecorpBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_individualownercontroller5id] ON [dbo].[fi_duediligencecorpBase] ([fi_individualownercontroller5id]) WHERE fi_individualownercontroller5id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_parentcustomercontactid' and id = OBJECT_ID('fi_contactauditlogBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_parentcustomercontactid] ON [dbo].[fi_contactauditlogBase] ([fi_parentcustomercontactid]) WHERE fi_parentcustomercontactid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_regardingcontactid' and id = OBJECT_ID('fi_relationshipreassignmentBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_regardingcontactid] ON [dbo].[fi_relationshipreassignmentBase] ([fi_regardingcontactid]) WHERE fi_regardingcontactid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_releatedcontact' and id = OBJECT_ID('fi_duediligenceindividualBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_releatedcontact] ON [dbo].[fi_duediligenceindividualBase] ([fi_releatedcontact]) WHERE fi_releatedcontact IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_settlorgrantordonor1id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_settlorgrantordonor1id] ON [dbo].[fi_duediligencetrustBase] ([fi_settlorgrantordonor1id]) WHERE fi_settlorgrantordonor1id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_settlorgrantordonor2id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_settlorgrantordonor2id] ON [dbo].[fi_duediligencetrustBase] ([fi_settlorgrantordonor2id]) WHERE fi_settlorgrantordonor2id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_settlorgrantordonor3id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_settlorgrantordonor3id] ON [dbo].[fi_duediligencetrustBase] ([fi_settlorgrantordonor3id]) WHERE fi_settlorgrantordonor3id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_settlorgrantordonor4id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_settlorgrantordonor4id] ON [dbo].[fi_duediligencetrustBase] ([fi_settlorgrantordonor4id]) WHERE fi_settlorgrantordonor4id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_trustauthorizedcontroller1id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_trustauthorizedcontroller1id] ON [dbo].[fi_duediligencetrustBase] ([fi_trustauthorizedcontroller1id]) WHERE fi_trustauthorizedcontroller1id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_trustauthorizedcontroller2id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_trustauthorizedcontroller2id] ON [dbo].[fi_duediligencetrustBase] ([fi_trustauthorizedcontroller2id]) WHERE fi_trustauthorizedcontroller2id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_trustauthorizedcontroller3id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_trustauthorizedcontroller3id] ON [dbo].[fi_duediligencetrustBase] ([fi_trustauthorizedcontroller3id]) WHERE fi_trustauthorizedcontroller3id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_trustauthorizedcontroller4id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_trustauthorizedcontroller4id] ON [dbo].[fi_duediligencetrustBase] ([fi_trustauthorizedcontroller4id]) WHERE fi_trustauthorizedcontroller4id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_trustee1id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_trustee1id] ON [dbo].[fi_duediligencetrustBase] ([fi_trustee1id]) WHERE fi_trustee1id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_trustee2id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_trustee2id] ON [dbo].[fi_duediligencetrustBase] ([fi_trustee2id]) WHERE fi_trustee2id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_trustee3id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_trustee3id] ON [dbo].[fi_duediligencetrustBase] ([fi_trustee3id]) WHERE fi_trustee3id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_trustee4id' and id = OBJECT_ID('fi_duediligencetrustBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_trustee4id] ON [dbo].[fi_duediligencetrustBase] ([fi_trustee4id]) WHERE fi_trustee4id IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO