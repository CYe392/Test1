IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_worknoteid' and id = OBJECT_ID('fi_activityworknoteassociationBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_worknoteid] ON [dbo].[fi_activityworknoteassociationBase] ([fi_worknoteid]) WHERE fi_worknoteid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_worknoteid' and id = OBJECT_ID('fi_fi_relationshipmanagementauditlogBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_worknoteid] ON [dbo].[fi_fi_relationshipmanagementauditlogBase] ([fi_worknoteid]) WHERE fi_worknoteid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_worknoteid' and id = OBJECT_ID('fi_incidentauditlogBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_worknoteid] ON [dbo].[fi_incidentauditlogBase] ([fi_worknoteid]) WHERE fi_worknoteid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_PerfRev_fk_fi_worknoteid' and id = OBJECT_ID('fi_opportunityauditlogBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_worknoteid] ON [dbo].[fi_opportunityauditlogBase] ([fi_worknoteid]) WHERE fi_worknoteid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO

--COMPLETED IN 15:20