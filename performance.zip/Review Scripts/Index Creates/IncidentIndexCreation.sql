IF EXISTS (select indid from sysindexes where name = 'ndx_fk_fi_caseid' and id = OBJECT_ID('fi_linkedtransferBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_caseid] ON [dbo].[fi_linkedtransferBase] ([fi_caseid]) WHERE fi_caseid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_fk_fi_incidentid' and id = OBJECT_ID('fi_incidentauditlogBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_incidentid] ON [dbo].[fi_incidentauditlogBase] ([fi_incidentid]) WHERE fi_incidentid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_fk_fi_incidentid' and id = OBJECT_ID('fi_teammembershipextensionBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_incidentid] ON [dbo].[fi_teammembershipextensionBase] ([fi_incidentid]) WHERE fi_incidentid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_fk_fi_originatingincidentid' and id = OBJECT_ID('fi_fi_relationshipmanagementauditlogBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_originatingincidentid] ON [dbo].[fi_fi_relationshipmanagementauditlogBase] ([fi_originatingincidentid]) WHERE fi_originatingincidentid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_fk_fi_originatingincidentid' and id = OBJECT_ID('fi_relationshipmanagementBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_originatingincidentid] ON [dbo].[fi_relationshipmanagementBase] ([fi_originatingincidentid]) WHERE fi_originatingincidentid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_fk_fi_reassignedincident' and id = OBJECT_ID('fi_relationshipreassignmentBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_reassignedincident] ON [dbo].[fi_relationshipreassignmentBase] ([fi_reassignedincident]) WHERE fi_reassignedincident IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO
IF EXISTS (select indid from sysindexes where name = 'ndx_fk_fi_regardingincidentid' and id = OBJECT_ID('fi_worknoteBase')) 
begin
print 'Index already exists. Index creation skipped.' 
end 
else 
begin
print 'Index creation started.'
CREATE NONCLUSTERED INDEX [ndx_PerfRev_fk_fi_regardingincidentid] ON [dbo].[fi_worknoteBase] ([fi_regardingincidentid]) WHERE fi_regardingincidentid IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO