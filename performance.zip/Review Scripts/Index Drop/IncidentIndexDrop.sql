DROP INDEX [dbo].[fi_linkedtransferBase].[ndx_PerfRev_fk_fi_caseid]; 
GO
DROP INDEX [dbo].[fi_incidentauditlogBase].[ndx_PerfRev_fk_fi_incidentid]; 
GO
DROP INDEX [dbo].[fi_teammembershipextensionBase].[ndx_PerfRev_fk_fi_incidentid]; 
GO
DROP INDEX [dbo].[fi_fi_relationshipmanagementauditlogBase].[ndx_PerfRev_fk_fi_originatingincidentid]; 
GO
DROP INDEX [dbo].[fi_relationshipmanagementBase].[ndx_PerfRev_fk_fi_originatingincidentid]; 
GO
DROP INDEX [dbo].[fi_relationshipreassignmentBase].[ndx_PerfRev_fk_fi_reassignedincident]; 
GO
DROP INDEX [dbo].[fi_worknoteBase].[ndx_PerfRev_fk_fi_regardingincidentid]; 
GO