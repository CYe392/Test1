DROP INDEX [dbo].[fi_activityworknoteassociationBase].[ndx_PerfRev_fk_fi_worknoteid]; 
GO
DROP INDEX [dbo].[fi_fi_relationshipmanagementauditlogBase].[ndx_PerfRev_fk_fi_worknoteid]; 
GO
DROP INDEX [dbo].[fi_incidentauditlogBase].[ndx_PerfRev_fk_fi_worknoteid]; 
GO
DROP INDEX [dbo].[fi_opportunityauditlogBase].[ndx_PerfRev_fk_fi_worknoteid]; 
GO