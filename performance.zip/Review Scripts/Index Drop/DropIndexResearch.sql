SELECT * FROM [dbo].[WorkNoteIndexTest]

SELECT * FROM [dbo].[WorkNoteIndexTest]

SELECT * FROM SYS.indexes
WHERE NAME LIKE '%PERF%'

DROP INDEX [dbo].[CustomerAddressBase].[NCX_PerfRev_CustomerAddressBase_City]; 
GO