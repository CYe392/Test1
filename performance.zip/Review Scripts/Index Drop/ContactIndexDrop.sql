DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_beneficiary1id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_beneficiary2id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_beneficiary3id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_beneficiary4id]; 
GO
DROP INDEX [dbo].[fi_duediligencecorpBase].[ndx_PerfRev_fk_fi_companydirector1id]; 
GO
DROP INDEX [dbo].[fi_duediligencecorpBase].[ndx_PerfRev_fk_fi_companydirector2id]; 
GO
DROP INDEX [dbo].[fi_duediligencecorpBase].[ndx_PerfRev_fk_fi_companydirector3id]; 
GO
DROP INDEX [dbo].[fi_duediligencecorpBase].[ndx_PerfRev_fk_fi_companydirector4id]; 
GO
DROP INDEX [dbo].[fi_duediligencecorpBase].[ndx_PerfRev_fk_fi_companydirector5id]; 
GO
DROP INDEX [dbo].[fi_sapphirelogBase].[ndx_PerfRev_fk_fi_contact]; 
GO
DROP INDEX [dbo].[fi_fi_cadextensionattributeauditlogBase].[ndx_PerfRev_fk_fi_contactid]; 
GO
DROP INDEX [dbo].[fi_fi_financialaccountauditlogBase].[ndx_PerfRev_fk_fi_contactid]; 
GO
DROP INDEX [dbo].[fi_duediligencecharityBase].[ndx_PerfRev_fk_fi_controller1id]; 
GO
DROP INDEX [dbo].[fi_duediligencecharityBase].[ndx_PerfRev_fk_fi_controller2id]; 
GO
DROP INDEX [dbo].[fi_duediligencecharityBase].[ndx_PerfRev_fk_fi_controller3id]; 
GO
DROP INDEX [dbo].[fi_duediligencecharityBase].[ndx_PerfRev_fk_fi_controller4id]; 
GO
DROP INDEX [dbo].[fi_incidentauditlogBase].[ndx_PerfRev_fk_fi_customerid]; 
GO
DROP INDEX [dbo].[fi_opportunityauditlogBase].[ndx_PerfRev_fk_fi_customerid]; 
GO
DROP INDEX [dbo].[fi_duediligencecharityBase].[ndx_PerfRev_fk_fi_directortrustee1id]; 
GO
DROP INDEX [dbo].[fi_duediligencecharityBase].[ndx_PerfRev_fk_fi_directortrustee2id]; 
GO
DROP INDEX [dbo].[fi_duediligencecharityBase].[ndx_PerfRev_fk_fi_directortrustee3id]; 
GO
DROP INDEX [dbo].[fi_duediligencecharityBase].[ndx_PerfRev_fk_fi_directortrustee4id]; 
GO
DROP INDEX [dbo].[fi_duediligencecorpBase].[ndx_PerfRev_fk_fi_individualownercontroller1id]; 
GO
DROP INDEX [dbo].[fi_duediligencecorpBase].[ndx_PerfRev_fk_fi_individualownercontroller2id]; 
GO
DROP INDEX [dbo].[fi_duediligencecorpBase].[ndx_PerfRev_fk_fi_individualownercontroller3id]; 
GO
DROP INDEX [dbo].[fi_duediligencecorpBase].[ndx_PerfRev_fk_fi_individualownercontroller4id]; 
GO
DROP INDEX [dbo].[fi_duediligencecorpBase].[ndx_PerfRev_fk_fi_individualownercontroller5id]; 
GO
DROP INDEX [dbo].[fi_contactauditlogBase].[ndx_PerfRev_fk_fi_parentcustomercontactid]; 
GO
DROP INDEX [dbo].[fi_relationshipreassignmentBase].[ndx_PerfRev_fk_fi_regardingcontactid]; 
GO
DROP INDEX [dbo].[fi_duediligenceindividualBase].[ndx_PerfRev_fk_fi_releatedcontact]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_settlorgrantordonor1id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_settlorgrantordonor2id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_settlorgrantordonor3id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_settlorgrantordonor4id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_trustauthorizedcontroller1id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_trustauthorizedcontroller2id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_trustauthorizedcontroller3id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_trustauthorizedcontroller4id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_trustee1id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_trustee2id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_trustee3id]; 
GO
DROP INDEX [dbo].[fi_duediligencetrustBase].[ndx_PerfRev_fk_fi_trustee4id]; 
GO