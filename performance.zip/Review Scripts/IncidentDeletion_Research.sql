exec sp_executesql N'SELECT * from [TaskBase] where ([ActivityId] = @ActivityId0);
SELECT * from [ActivityPointerBase]
	OUTPUT SELECTED.[ActivityId], 4212
		into SubscriptionTrackingDeletedObject (ObjectId, ObjectTypeCode)
 where ([ActivityId] = @ActivityId1)',N'@ActivityId0 uniqueidentifier,@ActivityId1 uniqueidentifier',@ActivityId0='143D25CC-6C6C-E411-940A-0025B50A007D',@ActivityId1='143D25CC-6C6C-E411-940A-0025B50A007D'

 select * from SubscriptionTrackingDeletedObject

 select * from ActivityPointerBase
 where ActivityId = '143D25CC-6C6C-E411-940A-0025B50A007D'

 select i.fi_Id_Search,t.* from incidentbase as i
 inner join ActivityPointerBase as ap
	on ap.RegardingObjectId = i.IncidentId
inner join TaskBase as t
	on t.ActivityId = ap.ActivityId
where i.fi_Id_Search in (7957869,
8285525,
8285523,
8288908,
8561458,
8285557,
8288842,
8961420,
8288782,
8288925,
7592906,
8297685,
8297692,
8288918,
8288900,
8349248,
8288766,
8372991,
8288887,
8288787,
8289167,
8288929,
7888469,
7793981,
7969848,
7765048,
7593026,
8297676,
8288944,
8358732,
8654869,
8288899,
8288812,
8297678,
8288940,
8285528,
8288771,
8288839,
8288790,
7970023,
8288913,
8288813,
8288817,
8288919,
8288894,
8285521,
8288882,
8288880,
8297675,
8297673,
8297686
)
order by i.fi_Id_Search
