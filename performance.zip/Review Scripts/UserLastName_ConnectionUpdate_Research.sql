select count(1) from ConnectionBase --87 119 180
where Record1IdName = 'Emma Nilles- MS Perf' --250764

select count(1) from ConnectionBase
where Record2IdName = 'Emma Nilles- MS Perf' --250764

--SET STATISTICS IO ON
--SET STATISTICS TIME ON

--SELECT act1044 FROM ConnectionBase 

SELECT Record2IdName FROM ConnectionBase 
WHERE Record2Id ='C5FE5BA6-BC6A-E411-93FD-0025B50B0088' AND Record2IdObjectTypeCode=8

SELECT Record1IdName FROM ConnectionBase 
WHERE Record1Id ='C5FE5BA6-BC6A-E411-93FD-0025B50B0088' AND Record1IdObjectTypeCode=8

exec sp_executesql N'update [ConnectionBase] set [Record2IdName]=@Record2IdName0 where 
([Record2Id] = @Record2Id0 and [Record2IdObjectTypeCode] = @Record2IdObjectTypeCode0)',N'@Record2IdName0 ntext,@Record2Id0 uniqueidentifier,@Record2IdObjectTypeCode0 int'
,@Record2IdName0=N'TEST',@Record2Id0='??',@Record2IdObjectTypeCode0=?

--SELECT * FROM Worktable 