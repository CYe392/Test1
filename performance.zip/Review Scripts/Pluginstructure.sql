select   
      CASE sdkmessageprocessingstep0.StateCode WHEN 0 Then 'Enabled' WHEN 1 Then 'Disabled' END as 'StatusName', 
      isNULL(e.Name, 'None') as 'EntityName', 
      CASE sdkmessageprocessingstep0.Stage  
WHEN 10 Then 'Pre-Out Of Trx' WHEN 20 Then 'Pre in Trx' WHEN 40 Then 'Post in Trx'  WHEN 50 Then 'Post-Out of Trx' END as 'StageName', 
      CASE PluginAssembly.IsolationMode  
            WHEN 1 Then 'Full' WHEN 2 Then 'Isolated-SandBox' else 'Unknown' END as 'IsolationModeName', 
      PluginAssembly.IsolationMode,  
      PluginAssembly.Version, 
      PluginAssembly.IsManaged,  
      sm.Name as 'MessageName',  
      PluginType0.componentstate as 'Assembly', 
      PluginType0.typename as 'Plugin', 
      CASE sdkmessageprocessingstep0.Mode WHEN 1 Then 'Asynchronous' WHEN 0 Then 'Synchronous' END as 'ModeName', 
      CASE ((coalesce(sdkmessageprocessingstep0.AsyncAutoDelete,0)*sdkmessageprocessingstep0.Mode)+sdkmessageprocessingstep0.Mode)  
            WHEN 1 Then 'No' WHEN 2 Then 'Yes' When 0 Then 'N/A' END as 'AsyncAutoDeleteName', 
      sdkmessageprocessingstep0.Rank as 'Rank',  
      CASE sdkmessageprocessingstep0.InvocationSource WHEN 0 Then 'Parent' WHEN 1 Then 'Child' END as 'PipelineName', 
      sdkmessageprocessingstep0.FilteringAttributes as 'FilteringAttributes', 
      sdkmessageprocessingstep0.Description as 'StepName',  
      sdkmessageprocessingstep0.AsyncAutoDelete,  
      sdkmessageprocessingstep0.Mode,  
      sdkmessageprocessingstep0.Stage, 
coalesce(pts.averageexecutetimeinmilliseconds,-1)'averageexecutetimeinmilliseconds', 
coalesce(pts.executecount,-1)'executecount' 
  from SdkMessageProcessingStep as sdkmessageprocessingstep0  
      inner join PluginType PluginType0 on PluginType0.PluginTypeId = sdkmessageprocessingstep0.PluginTypeId 
      inner join sdkmessagefilter filter on filter.SdkMessageFilterId = sdkmessageprocessingstep0.SdkMessageFilterId 
      inner join PluginAssembly PluginAssembly on PluginType0.PluginAssemblyId = PluginAssembly.PluginAssemblyId 
      join SdkMessage sm on sm.SdkMessageId=filter.SdkMessageId 
      join EntityLogicalView e on filter.PrimaryObjectTypeCode=e.ObjectTypeCode 
  left outer join plugintypestatistic pts on pts.plugintypeid = PluginType0.plugintypeid 
      where  
  ((sdkmessageprocessingstep0.CustomizationLevel != 2 or sdkmessageprocessingstep0.CustomizationLevel is null)  
      and ((sdkmessageprocessingstep0.Stage in (10, 20, 40, 50)))) 
      and FriendlyName not in ('InternalOperation') 
 order by averageexecutetimeinmilliseconds DESC, e.Name, Stage DESC, MessageName, sdkmessageprocessingstep0.Rank

