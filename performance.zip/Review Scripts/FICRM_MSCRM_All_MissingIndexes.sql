--Get list of entitiy Ids for Indexes
/*
select  distinct cast(a.ReferencedEntityObjectTypeCode as varchar(5)) + ','
FROM Attribute a 
Join entity e on a.entityid = e.entityid
Join entity rOTC on rOTC.objecttypecode = a.ReferencedEntityObjectTypeCode
where 
IsCustomField = 1 --May need to comment this line out for out of box entities 
AND AttributeTypeId = '00000000-0000-0000-00AA-110000000031' and ReferencedEntityObjectTypeCode not in (0,1019,8)
*/

;with cte as
(
SELECT DISTINCT
case 
when ic2.ColumnName is null then 
'IF EXISTS (select indid from sysindexes where name = ''ndx_fk_' + a.Name + ''' and id = OBJECT_ID('''+Coalesce(e.ExtensionTableName, e.BaseTableName)+''')) 
begin
print ''Index already exists. Index creation skipped.'' 
end 
else 
begin
print ''Index creation started.''
CREATE NONCLUSTERED INDEX [ndx_fk_' + a.Name + '] ON [dbo].[' + Coalesce(e.ExtensionTableName, e.BaseTableName) + '] ([' + a.name + ']) WHERE ' + a.name + ' IS NOT NULL 
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY] 
End 
GO' 
else 'IndexAlreadyExists!' end as IndexCreate, 
case 
when ic2.ColumnName is null then 
'DROP INDEX [dbo].[' + Coalesce(e.ExtensionTableName, e.BaseTableName) + '].[ndx_fk_' + a.Name + ']; 
GO' 
else --For already existing indexes we'll show the drop  
'DROP INDEX [dbo].[' + Coalesce(e.ExtensionTableName, e.BaseTableName) + '].[ndx_fk_' + a.Name + ']; 
GO' 
end as IndexDrop, 
case 
when ic2.ColumnName is null then 
'sqlcmd -l 120 -I -S ScaleGroupListener -d  DBNAME -Q "DROP INDEX [dbo].[' + Coalesce(e.ExtensionTableName, e.BaseTableName) + '].[ndx_fk_' + a.Name + ']"' 
else 'IndexAlreadyExists!' 
end as IndexRollback 
,e.name [EntityName] 
,a.name [AttributeName] 
,rOTC.Name [ReferencedEntity] 
,a.ReferencedEntityObjectTypeCode, 
Coalesce(e.ExtensionTableName, e.BaseTableName) as TableName, 
--,t.object_id,ic2.ColumnName,ic2.name as IndexName, 
case 
WHEN ic2.columnname is null THEN 'Index Missing'  
ELSE 'Index Exists: ' + ic2.name    
end as 'Status' 
FROM Attribute a  
Join entity e on a.entityid = e.entityid 
Join entity rOTC on rOTC.objecttypecode = a.ReferencedEntityObjectTypeCode 
Join sys.tables t on t.name = Coalesce(e.ExtensionTableName, e.BaseTableName) 
Left outer join (select ic.object_id, c.name as ColumnName, i.name from sys.indexes i  
join sys.index_columns ic 
on i.object_id = ic.object_id and i.index_id = ic.index_id 
join sys.columns c 
on c.column_id = ic.column_id and c.object_id = ic.object_id 
where type = 2 and ic.key_ordinal = 1 )ic2 
on ic2.ColumnName = a.Name and ic2.object_id = t.object_id 
Where  
ReferencedEntityObjectTypeCode IN
(
1,
10,
10001,
10003,
10004,
10006,
10011,
10018,
10019,
10021,
10024,
10026,
10034,
10037,
10039,
10042,
10043,
10045,
10046,
10047,
10048,
10053,
10055,
10057,
10065,
10066,
10070,
10085,
10086,
10087,
10088,
10089,
10091,
10092,
10094,
1022,
1024,
1036,
112,
2,
3,
4212,
4300,
4400,
9,
9105,
9606
)
and IsCustomField = 1 --May need to comment this line out for out of box entities  
AND AttributeTypeId = '00000000-0000-0000-00AA-110000000031' and ReferencedEntityObjectTypeCode not in (0,1019) 
--and ic2.ColumnName is not null 
--order by Status desc 
 
)
select * --into mscrm_custom.dbo.WorkNoteIndexTest

from cte
order by Status desc 

--drop table IndexTest

--SELECT * FROM mscrm_custom.dbo.IncidentIndexTest

--SELECT * FROM mscrm_custom.dbo.ContactIndexTest

--(254 row(s) affected) INDEXES TO BE CREATED