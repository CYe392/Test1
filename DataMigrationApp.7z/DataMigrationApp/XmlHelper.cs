﻿using DataMigrationApp.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace DataMigrationApp
{
    public class XmlHelper
    {
        XmlDocument _root;
        public XmlHelper(XmlDocument Root)
        {
            this._root = Root;
        }

        public void AddAttribute(XmlElement node, string attrName, object attrVal)
        {
            var propAtr = _root.CreateAttribute(attrName);
            propAtr.Value = attrVal.ToString();
            node.Attributes.Append(propAtr);
        }

        public void AddChild(XmlElement parentNode, object children)
        {
            if (children == null)
                return;

            var childType = children.GetType();
            PropertyInfo[] childProp = childType.GetProperties(BindingFlags.Public);

            XmlElement childNode = null;
            var childConfig = childType.GetCustomAttribute<AttributePropertyConfig>();
            if (childConfig.AddNode)
                childNode = _root.CreateElement(childType.Name);

            foreach (var prop in childProp)
            {
                var propVal = prop.GetValue(children);
                if (propVal != null)
                {
                    var propertyType = prop.GetCustomAttribute<AttributePropertyConfig>();
                    switch (propertyType.PropertyType)
                    {
                        case PropertyType.Element:
                            if (prop.PropertyType.IsArray)
                            {
                                foreach (var item in (IEnumerable<object>)propVal)
                                {
                                    if (childNode != null)
                                        AddChild(childNode, item);
                                    else
                                        AddChild(parentNode, item);
                                }
                            }
                            else
                            {
                                if (childNode != null)
                                    AddChild(childNode, propVal);
                                else
                                    AddChild(parentNode, propVal);
                            }
                            break;
                        case PropertyType.Attribute:
                            var customeName = prop.GetCustomAttribute<DisplayAttribute>();
                            string attributeName = prop.Name;
                            if (customeName != null)
                                attributeName = customeName.GetName();
                            AddAttribute(childNode, attributeName, propVal);
                            break;
                        case PropertyType.Value:
                            if (childNode != null)
                                AddValue(childNode, propVal);
                            else
                                AddValue(parentNode, propVal);
                            break;
                    }
                }
            }
            if (childNode != null)
            {
                if (parentNode != null)
                    parentNode.AppendChild(childNode);
                else
                    _root.AppendChild(childNode);
            }
        }

        public void AddValue(XmlElement parentNode, object propVal)
        {
            parentNode.Value = propVal.ToString();
        }

        public void Save(string fileName)
        {
            _root.Save(fileName);
        }
    }
}
