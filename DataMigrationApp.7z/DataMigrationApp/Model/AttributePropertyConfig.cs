﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataMigrationApp.Model
{
    public class AttributePropertyConfig : Attribute
    {
        public PropertyType PropertyType;
        public bool AddNode = true;
        public AttributePropertyConfig(PropertyType type)
        {
            this.PropertyType = type;
        }
        public AttributePropertyConfig(PropertyType type, bool addNode)
        {
            this.PropertyType = type;
            this.AddNode = addNode;
        }
    }
}
