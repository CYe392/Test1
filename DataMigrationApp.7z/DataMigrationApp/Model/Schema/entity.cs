﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataMigrationApp.Model.Schema
{
    [AttributePropertyConfig(PropertyType.Element)]
    public class entity
    {
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string name;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string displayname;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string primaryidfield;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string primarynamefield;
        int _etc;
        bool? _disableplugins;

        [AttributePropertyConfig(PropertyType.Element)]
        public List<field> fields;
        [AttributePropertyConfig(PropertyType.Element)]
        public List<relationship> relationships;

        [AttributePropertyConfig(PropertyType.Attribute)]
        public string etc
        {
            get { return _etc.ToString(); }
            set { _etc = Convert.ToInt32(value); }
        }

        [AttributePropertyConfig(PropertyType.Attribute)]
        public string disableplugins
        {
            get { return _disableplugins.ToString(); }
            set
            {
                if (!string.IsNullOrEmpty(value))
                    _disableplugins = string.Equals(value, "true", StringComparison.InvariantCultureIgnoreCase);
            }
        }
    }
}
