﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataMigrationApp.Model.Schema
{
    [AttributePropertyConfig(PropertyType.Element)]
    public class entities
    {
        [Display(Name = "xmlns:xsi")]
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string xsi = "http://www.w3.org/2001/XMLSchema-instance";

        [AttributePropertyConfig(PropertyType.Element, false)]
        public List<entity> entity;
    }
}
