﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataMigrationApp.Model.Schema
{
    [AttributePropertyConfig(PropertyType.Element)]
    public class field
    {
        FieldType _type;

        [AttributePropertyConfig(PropertyType.Attribute)]
        public bool primaryKey;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string displayname;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string name;        
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string type
        {
            get
            {
                return _type.ToString();
            }
            set
            {
                _type = (FieldType)Enum.Parse(typeof(FieldType), value);
            }
        }
        [AttributePropertyConfig(PropertyType.Attribute)]
        public bool customfield;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string lookupType;
    }
}
