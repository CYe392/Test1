﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataMigrationApp.Model.Schema
{
    [AttributePropertyConfig(PropertyType.Element)]
    public class relationship
    {
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string name;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public bool manyToMany;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public bool isreflexive;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string relatedEntityName;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string m2mTargetEntity;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string m2mTargetEntityPrimaryKey;
    }
}
