﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataMigrationApp.Model.Data
{
    [AttributePropertyConfig(PropertyType.Element)]
    public class field
    {
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string name;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string value;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string lookupentity;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string lookupentityname;
    }
}
