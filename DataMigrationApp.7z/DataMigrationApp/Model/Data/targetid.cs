﻿using System;

namespace DataMigrationApp.Model.Data
{
    [AttributePropertyConfig(PropertyType.Element)]
    public class targetid
    {
        Guid _id;
        [AttributePropertyConfig(PropertyType.Value)]
        public string id
        {
            get
            {
                return _id.ToString();
            }
            set
            {
                _id = new Guid(id);
            }
        }
    }
}