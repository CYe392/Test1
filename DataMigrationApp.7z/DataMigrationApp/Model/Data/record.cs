﻿using System;
using System.Collections.Generic;

namespace DataMigrationApp.Model.Data
{
    [AttributePropertyConfig(PropertyType.Element)]
    public class record
    {
        Guid _id;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string id
        {
            get
            {
                return _id.ToString();
            }
            set
            {
                _id = new Guid(id);
            }
        }
        [AttributePropertyConfig(PropertyType.Element, false)]
        public List<field> fields;
    }
}