﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataMigrationApp.Model.Data
{
    [AttributePropertyConfig(PropertyType.Element)]
    public class entity
    {
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string name;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string displayname;
        [AttributePropertyConfig(PropertyType.Element)]
        public List<record> records;
        [AttributePropertyConfig(PropertyType.Element)]
        public List<m2mrelationship> m2mrelationships;
    }
}
