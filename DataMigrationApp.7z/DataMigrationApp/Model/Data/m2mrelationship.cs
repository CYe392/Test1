﻿using System;
using System.Collections.Generic;

namespace DataMigrationApp.Model.Data
{
    [AttributePropertyConfig(PropertyType.Element)]
    public class m2mrelationship
    {
        [AttributePropertyConfig(PropertyType.Attribute)]
        public Guid sourceid;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string targetentityname;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string targetentitynameidfield;
        [AttributePropertyConfig(PropertyType.Attribute)]
        public string m2mrelationshipname;
        [AttributePropertyConfig(PropertyType.Element)]
        public List<targetid> targetids;
    }
}