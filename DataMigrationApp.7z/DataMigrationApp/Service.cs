﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;


namespace DataMigrationApp
{
    public class Service
    {
        Repository repository;
        Model.Schema.entities Schema;
        Model.Data.entities Data;

        public Service()
        {
            repository = new Repository();
        }

        public void Initialize()
        {
            Schema = new Model.Schema.entities();
            Data = new Model.Data.entities();
        }

        public void AddQuery(string fetchxml)
        {
            //Get columnset, link entities
            var query = repository.GetQueryExpression(fetchxml);
            //get data
            List<Entity> result = repository.Fetch(query);
            if (result.Count == 0) return;
            var existNodeSchema = Schema.entity.FirstOrDefault(e => e.name == result.First().LogicalName);
            if (existNodeSchema == null) {
                existNodeSchema = new Model.Schema.entity();
                existNodeSchema.name = query.EntityName;
                existNodeSchema.displayname = query.EntityName;
                existNodeSchema.etc = query.EntityName;

                Schema.entity.Add(existNodeSchema);
            }
            //Add new field definitions into existNodeSchema
            foreach (var col in query.ColumnSet.Columns)
            {
                //if (existNodeSchema)
                //}
            //Add new m2mrelationships into existNodeSchema
        }

        public void CreateSchema(Model.Schema.entities entities)
        {
            var helper = new XmlHelper(new XmlDocument());
            helper.AddChild(null, entities);
            helper.Save("data_schema.xml");
        }

        public void CreateData(Model.Data.entity entities)
        {
            var helper = new XmlHelper(new XmlDocument());
            helper.AddChild(null, entities);
            helper.Save("data.xml");
        }

        public void CreateContentType() {
            string xml = @"<?xml version='1.0' encoding='utf-8'?>
                            <Types xmlns='http://schemas.openxmlformats.org/package/2006/content-types'>
                                <Default Extension='xml' ContentType='application/octet-stream' />
                            </Types>";
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);
            doc.Save("[Content_Types].xml");
        }
    }
}
