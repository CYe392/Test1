﻿using DataMigrationApp.Model;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataMigrationApp
{
    public class Repository
    {
        string _crmUrl;
        OrganizationServiceProxy _service;
        public Repository()
        {
            _crmUrl = ConfigurationManager.AppSettings["CRMUrl"];
        }
        public OrganizationServiceProxy Service()
        {
            if (_service == null)
                _service = new OrganizationServiceProxy(new Uri(_crmUrl), null, null, null);
            return _service;
        }

        public OrganizationServiceContext Context()
        {
            return new OrganizationServiceContext(Service());
        }

        public QueryExpression GetQueryExpression(string fetchxml)
        {
            var request = new FetchXmlToQueryExpressionRequest();
            request.FetchXml = fetchxml;
            var result = (FetchXmlToQueryExpressionResponse)Service().Execute(request);
            return result.Query;
        }

        public List<Entity> Fetch(QueryExpression query)
        {
            query.PageInfo = new PagingInfo();
            query.PageInfo.Count = 1000;
            query.PageInfo.PageNumber = 1;
            query.PageInfo.PagingCookie = null;

            List<Entity> res = new List<Entity>();
            while (true)
            {
                var result = Service().RetrieveMultiple(query);
                res.AddRange(result.Entities.ToList());
                if (result.MoreRecords)
                {
                    query.PageInfo.PageNumber++;
                    query.PageInfo.PagingCookie = result.PagingCookie;
                }
                else
                    break;
            }
            return res;
        }
    }
}
