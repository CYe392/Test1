select pa.Name,
pa.Version,
pa.CreatedOn,
pa.ModifiedOn,
pa.SourceType,
pa.CustomizationLevel,
pa.IsolationMode,
pa.IsHidden,
pa.SolutionId,
pa.PluginAssemblyId, 
sol.Description
from PluginAssembly pa
left outer join solution sol on
sol.SolutionId = pa.SolutionId
order by pa.Name