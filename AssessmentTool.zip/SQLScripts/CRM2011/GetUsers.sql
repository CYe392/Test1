select 
su.systemuserid,
su.BusinessUnitIdName,
su.IsDisabled 
from SystemUser su
order by su.BusinessUnitIdName, su.DomainName