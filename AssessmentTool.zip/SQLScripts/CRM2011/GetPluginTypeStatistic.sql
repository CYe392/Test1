select 
pt.Name,
pts.TerminateMemoryContributionPercent,
pts.TerminateHandlesContributionPercent,
pts.TerminateCpuContributionPercent,
pts.TerminateOtherContributionPercent,
pts.AverageExecuteTimeInMilliseconds,
pts.FailurePercent,
pts.CrashCount,
pts.CrashContributionPercent,
pts.CrashPercent,
pts.FailureCount,
pts.FailurePercent,
pts.ExecuteCount,
pts.plugintypeid
from PluginType pt
left outer join PluginTypeStatistic pts on
pts.PluginTypeId = pt.PluginTypeId
order by pt.Name