select
 FileSize
,CreatedOn
,ObjectTypeCode
,case
    when patindex('%.%', FileName) > 0 then 
		upper(reverse(substring(reverse(FileName), 1, patindex('%.%', reverse(FileName))-1)))
    else ''
end as FileType

from Annotation
where IsDocument = 1