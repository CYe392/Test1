select
team.teamid,
team.Name,
team.BusinessUnitIdName
from Team team
order by team.Name