select 
wf.Name,
wf.Description,
wf.PrimaryEntity,
(select top 1 Name from Entity where entity.ObjectTypeCode = wf.PrimaryEntity) as EntityName,
wf.type,
wfd.ParameterName,
wfd.ParameterType,
wfd.RelatedEntityName,
wfd.RelatedAttributeName,
wfd.CreatedOn wfdCreatedOn,
wfd.ModifiedOn wfdModifiedOn,
wfd.CreatedOn,
wfd.ModifiedOn,
wfd.WorkflowId,
wfd.Type wfdType,
wfd.CustomEntityName,
wfd.DependentEntityName,
wfd.DependentAttributeName,
wf.IsCrmUIWorkflow,
wf.Subprocess,
wf.Scope,
wf.StatusCode,
wf.AsyncAutoDelete,
wf.TriggerOnCreate,
wf.Category,
wf.TriggerOnDelete,
wf.IsCustomizable,
wf.TriggerOnUpdateAttributeList,
wf.IsManaged,
wf.ActiveWorkflowIdName,
wf.ActiveWorkflowId,
wf.ParentWorkflowIdName,
wf.ParentWorkflowId,
wf.OnDemand,
wf.CreatedOn wfCreatedOn,
wf.ModifiedOn wfModifiedOn

from workflow wf
left outer join WorkflowDependency wfd on
wfd.workflowid = wf.WorkflowId
where wf.type = 1 -- (1=definition)
order by wf.PrimaryEntity, wf.Name, wf.Type
