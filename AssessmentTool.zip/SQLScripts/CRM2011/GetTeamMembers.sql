select
team.Name as TeamName,
team.BusinessUnitIdName,
team.teamid,
su.systemuserid
from Team team
left outer join TeamMembership mbr on
mbr.TeamId = team.TeamId
left outer join SystemUser su on 
su.SystemUserId = mbr.SystemUserId
order by team.Name, su.DomainName