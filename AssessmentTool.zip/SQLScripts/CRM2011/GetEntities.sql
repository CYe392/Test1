select
ent.basetablename, 
ent.entityid,
ent.Name,
ent.ObjectTypeCode,
ent.PhysicalName,
ent.LogicalName,
ent.IsIntersect, 
ent.IsLookupTable,
ent.IsCustomizable,
ent.IsActivity,
ent.IsAudited,
ent.IsParented,
ent.IsReplicated,
ent.IsChildEntity,
ent.IsCustomEntity,
ent.ReportViewName,
ent.IsRequiredOffline,
ent.SolutionId,
sol.Description,
sol.FriendlyName,
sol.UniqueName,
sol.IsManaged
from entity ent
left outer join solution sol on
sol.SolutionId = ent.SolutionId
order by Name