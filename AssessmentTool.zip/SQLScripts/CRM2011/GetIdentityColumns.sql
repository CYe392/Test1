SELECT
	t.name,
	c.name
FROM sys.tables AS T
LEFT OUTER JOIN sys.columns AS C
    ON T.[object_id] = C.[object_id]
where c.is_identity = 1
ORDER BY
    t.name ASC;