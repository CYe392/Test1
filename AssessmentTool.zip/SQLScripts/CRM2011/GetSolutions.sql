select 
sol.PublisherId,
sol.SolutionId,
sol.Description,
sol.FriendlyName,
sol.InstalledOn,
sol.IsManaged,
sol.IsVisible,
sol.CreatedBy,
sol.CreatedOn,
sol.ModifiedBy,
sol.OrganizationIdName,
sol.PublisherIdName,
sol.UniqueName,
sol.Version,
sol.VersionNumber
from solution sol
order by sol.FriendlyName