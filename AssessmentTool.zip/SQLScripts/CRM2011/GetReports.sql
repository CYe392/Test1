select 
(select top 1 entity.name from entity where entity.ObjectTypeCode = rptent.ObjectTypeCode) as EntityName,
rpt.reportid,
rpt.IsCustomizable,
rpt.IsCustomReport,
rpt.IsManaged,
rpt.IsPersonal,
rpt.IsScheduledReport,
rpt.CreatedOn,
rpt.ModifiedOn,
rpt.MimeType,
rpt.VersionNumber,
rpt.ReportTypeCode

from report rpt
left outer join ReportEntity rptent on
rptent.reportid = rpt.reportid
where ltrim(rtrim(rpt.ModifiedByName)) != 'system'
order by rpt.Name