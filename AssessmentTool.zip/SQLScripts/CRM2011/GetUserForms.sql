select 
uf.CreatedOn,
uf.ModifiedOn,
uf.ObjectTypeCode,
uf.Type
from UserForm uf
order by uf.ModifiedOn