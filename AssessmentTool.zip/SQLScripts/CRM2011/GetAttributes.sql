SELECT [AttributeId]
from AttributeIds