SELECT o.[name] AS [Table], tr.[name] AS [Trigger], tr.crdate as CreatedDate, tr.refdate as RefDate
FROM	[sysobjects] o
JOIN	[sysobjects] tr
ON		o.[id] = tr.[parent_obj]
WHERE	tr.[type] = 'tr'
ORDER BY [Table], [Trigger]