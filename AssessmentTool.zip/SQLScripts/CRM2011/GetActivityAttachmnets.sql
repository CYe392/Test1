select

FileSize
,ObjectTypeCode

from ActivityAttachment