select 
pt.Name,
pt.plugintypeid,
pt.FriendlyName,
pt.TypeName,
pt.IsWorkflowActivity,
pt.WorkflowActivityGroupName,
pt.PluginTypeIdUnique,
pt.Version,
pt.CreatedOn,
pt.ModifiedOn,
pt.CustomizationLevel,
pt.IsManaged,
pt.SolutionId,
pt.assemblyname, 
sol.Description
from PluginType pt
left outer join solution sol on
sol.SolutionId = pt.SolutionId
order by pt.Name