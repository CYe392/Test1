select 
role.Name as RoleName,
role.BusinessUnitIdName,
role.IsManaged,
role.roleid,
su.systemuserid,
su.IsDisabled
from role role
left outer join BusinessUnit bu on
bu.BusinessUnitId = role.BusinessUnitId
left outer join SystemUserRoles sur on 
sur.RoleId = role.RoleId
left outer join SystemUser su on 
su.SystemUserId = sur.SystemUserId
where 
su.DomainName is not null
order by role.Name, bu.name, su.DomainName