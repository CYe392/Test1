select
uqv.CreatedOn,
uqv.ModifiedOn,
uqv.PrimaryEntityTypeCode
from UserQueryVisualization uqv
order by uqv.ModifiedOn