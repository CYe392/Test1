SET ANSI_WARNINGS OFF

-- create temporary tables
declare @TempTable1 table
(Name nvarchar(128)
,Rows char(11)
,Reserved varchar(18)
,Data varchar(18)
,IndexSize varchar(18)
,Unused varchar(18)
)
declare @TempTable2 table
(Name nvarchar(128)
,Rows char(11)
,Reserved varchar(18)
,Data varchar(18)
,IndexSize varchar(18)
,Unused varchar(18)
,Rows_INT int
,Reserved_GB decimal(18,5)
,Data_GB decimal(18,5)
,IndexSize_GB decimal(18,5)
,Unused_GB decimal(18,5)
)

-- local variables
declare @UserTableName nvarchar(40)
declare UserTableSize cursor for
select rtrim(name) from dbo.sysobjects
where OBJECTPROPERTY(id, N'IsUserTable') = 1 order by name

-- run MSFT stored proc to get size info 
open UserTableSize
fetch next from UserTableSize into @UserTableName
while @@fetch_status = 0
begin
	begin try
		Insert @temptable1
		exec sp_spaceused @UserTableName
	end try
	begin catch
	end catch
    fetch next from UserTableSize into @UserTableName
end
close UserTableSize
deallocate UserTableSize

--	merge the tables
insert into @TempTable2
select Name, Rows, Reserved, Data, IndexSize, Unused, null, null, null, null, null from @TempTable1

-- declare columns to use in calculation
declare @Name nvarchar(128)
declare @Rows char(11)
declare @Reserved varchar(18)
declare @Data varchar(18)
declare @IndexSize varchar(18)
declare @Unused varchar(18)
declare @Rows_INT as int
declare @Reserved_GB decimal(18,5)
declare @Data_GB decimal(18,5)
declare @IndexSize_GB decimal(18,5)
declare @Unused_GB decimal(18,5)
declare UpdateTempTable cursor for
select Name, Rows, Reserved, Data, IndexSize, Unused from @temptable2

-- calculate values for MB columns
open UpdateTempTable
fetch next from UpdateTempTable into @Name, @Rows, @Reserved, @Data, @IndexSize, @Unused
while @@fetch_status = 0
begin
	--	convert strings to numbers
	set @Rows_INT = convert(int, @Rows)
	set @Reserved_GB = convert(decimal(18,5), replace(@Reserved, 'KB', ''))
	set @Data_GB = convert(decimal(18,5), replace(@Data, 'KB', ''))
	set @IndexSize_GB = convert(decimal(18,5), replace(@IndexSize, 'KB', ''))
	set @Unused_GB = convert(decimal(18,5), replace(@Unused, 'KB', ''))

	--	convert values to GB
	set @Reserved_GB = @Reserved_GB / 1024 / 1024
	set @Data_GB = @Data_GB / 1024 / 1024
	set @IndexSize_GB = @IndexSize_GB / 1024 / 1024
	set @Unused_GB = @Unused_GB / 1024 / 1024

	--	update the record
	update @temptable2
	set Name = replace(@Name, 'Base', ''),
		Rows_INT = @Rows,
		Reserved_GB = @Reserved_GB,
		Data_GB = @Data_GB,
		IndexSize_GB = @IndexSize_GB,
		Unused_GB = @Unused_GB
	where Name = @Name 

	--	get next record
    fetch next from UpdateTempTable into @Name, @Rows, @Reserved, @Data, @IndexSize, @Unused
end
close UpdateTempTable
deallocate UpdateTempTable

--	dump results
--Select *  from @temptable
Select *  from @temptable2 order by name



