select distinct
role.RoleId,
role.BusinessUnitIdName,
role.ismanaged,
role.BusinessUnitId,
role.Name as RoleName
from role role
order by role.Name 