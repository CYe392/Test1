select 
uq.CreatedOn,
uq.ModifiedOn,
uq.QueryType
from UserQuery uq
order by uq.ModifiedOn