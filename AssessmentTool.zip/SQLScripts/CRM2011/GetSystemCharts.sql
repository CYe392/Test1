select
sqv.CreatedOn,
sqv.ModifiedOn,
sqv.PrimaryEntityTypeCode
from SavedQueryVisualization sqv
order by sqv.ModifiedOn