select 
wf.Name,
wf.workflowid,
wf.Description,
wf.PrimaryEntity,
(select top 1 Name from Entity where entity.ObjectTypeCode = wf.PrimaryEntity) as EntityName,
wf.type,
wf.IsCrmUIWorkflow,
wf.Subprocess,
wf.Scope,
wf.StatusCode,
wf.AsyncAutoDelete,
wf.TriggerOnCreate,
wf.Category,
wf.TriggerOnDelete,
wf.IsCustomizable,
wf.TriggerOnUpdateAttributeList,
wf.IsManaged,
wf.ActiveWorkflowIdName,
wf.ActiveWorkflowId,
wf.ParentWorkflowIdName,
wf.ParentWorkflowId,
wf.OnDemand,
wf.CreatedOn,
wf.ModifiedOn

from workflow wf
where wf.type = 1 -- (1=definition)
order by wf.PrimaryEntity, wf.Name, wf.Type