--	create the publisher table
declare @temppublisher table
(
	customizationprefix nvarchar(8),
	description nvarchar(2000)
)

--	declare the cursor
declare readpub cursor for
select pub.customizationprefix, pub.description
from publisher pub
where pub.CustomizationPrefix != 'none'

--	open cursor, get first record
declare @customizationprefix nvarchar(8)
declare @description nvarchar(2000)
declare @count int
open readpub 
fetch next from readpub into @customizationprefix, @description
while (@@FETCH_STATUS = 0)
begin
	--	does prefix exist?
	set @count = 0
	set @count = (select count(*) from @temppublisher 
				where customizationprefix = @customizationprefix)
	if (@count is null or @count = 0)
	begin
		--	save publisher prefix
		insert into @temppublisher 
			(customizationprefix, description)
		values 
			(@customizationprefix, @description)
	end
	--	read next record
	fetch next from readpub into @customizationprefix, @description
end

-- close the cursor
close readpub
deallocate readpub

--	create the entity custom fields table
declare @entitycustomfield table
(
	solutionid uniqueidentifier,
	objecttypecode int,
	entityname nvarchar(64),
	logicalname nvarchar(50),
	attributedescription nvarchar(255),
	sqlservertype int
)

--	declare the cursor
declare readtemppub cursor for
select temppub.customizationprefix, temppub.description
from @temppublisher temppub

--	declare local values
declare @compareprefix nvarchar(10)
declare @solutionid uniqueidentifier
declare @objecttypecode int
declare @entityname nvarchar(64)
declare @logicalname nvarchar(50)
declare @attributedescription nvarchar(255)
declare @sqlservertype int

--	open cursor, get first record
open readtemppub 
fetch next from readtemppub into @customizationprefix, @description
while (@@FETCH_STATUS = 0)
begin
	set @compareprefix = ltrim(rtrim(@customizationprefix)) + '_%'
	--	declare the cursor
	declare readentity cursor for
		select 
		attr.SolutionId,
		ent.ObjectTypeCode,
		ent.LogicalName,
		attr.LogicalName,
		attrtype.Description,
		attrtype.SQLServerType
		from entity ent 
		join attribute attr on 
		attr.entityid = ent.entityid
		join AttributeTypes attrtype on
		attrtype.AttributeTypeId = attr.AttributeTypeId
		where attr.LogicalName like @compareprefix
		and ent.LogicalName not like @compareprefix

	--	open the entity cursor
	open readentity 
	fetch next from readentity into @solutionid, @objecttypecode, @entityname, @logicalname, @attributedescription, @sqlservertype
	while (@@FETCH_STATUS = 0)
	begin
		--	check if the record exists
		set @count = 0
		set @count = (select count(*) from @entitycustomfield 
					where solutionid = @solutionid 
					and entityname = @entityname
					and logicalname = @logicalname)

		--	insert the entity & custom field info
		if (@count is null or @count = 0)
		begin
			insert into @entitycustomfield
				(solutionid, objecttypecode, entityname, logicalname, attributedescription, sqlservertype)
			values
				(@solutionid, @objecttypecode, @entityname, @logicalname, @attributedescription, @sqlservertype)
		end
					
		--	read next record
		fetch next from readentity into @solutionid, @objecttypecode, @entityname, @logicalname, @attributedescription, @sqlservertype
	end

	-- close the cursor
	close readentity
	deallocate readentity

	--	read next record
	fetch next from readtemppub into @customizationprefix, @description
end

-- close the cursor
close readtemppub
deallocate readtemppub

--select * from @temppublisher
select * from @entitycustomfield order by entityname, logicalname