--	create the hierarchy table
declare @templookup table
(
	id uniqueidentifier,
	pid uniqueidentifier,	
	businessunitname nvarchar(160),
	parentbusinessunitname nvarchar(160),
	seqnbr int identity(1,1)
)

-- insert top level record
insert into @templookup
select bu.businessunitid, bu.ParentBusinessUnitId, bu.Name, bu.ParentBusinessUnitIdName
from BusinessUnit bu
where bu.ParentBusinessUnitId is null

-- process until all children found
declare @bdone bit
set @bdone = 0
while (@bdone = 0)
begin
	-- set flag to quit loop
    set @bdone = 1
	-- find the last id inserted into the temp table
	declare @id uniqueidentifier
	set @id = (select top 1 id from @templookup order by seqnbr desc)
	if (@id is not null)
	begin
		--	check if id is parent to another record
		declare @buid uniqueidentifier
		set @buid = (select top 1 bu2.businessunitid from businessunit bu2 where bu2.ParentBusinessUnitId = @id)
		if (@buid is not null)
		begin
			-- its a parent, check if in temp table
			declare @checkid uniqueidentifier
			set @checkid = (select id from @templookup where id = @buid)
			if (@checkid is null)
			begin
				-- insert bu info into temp table
				insert into @templookup
				select bu.businessunitid, bu.ParentBusinessUnitId, bu.Name, bu.ParentBusinessUnitIdName
				from BusinessUnit bu
				where bu.businessunitid = @buid
				-- indicate we are not done
				set @bdone = 0
			end
		end
	end
end

select * from @templookup