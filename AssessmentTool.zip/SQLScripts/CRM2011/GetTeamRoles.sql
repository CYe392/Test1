select 
team.TeamId,
team.name TeamName,
role.Name RoleName,
role.RoleId
from team team
left outer join TeamRoles tr on
tr.TeamId = team.TeamId
left outer join role role on 
role.roleid = tr.RoleId