select
team.teamid,
team.Name,
team.BusinessUnitIdName,
team.TeamType
from Team team
order by team.Name