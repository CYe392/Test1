select 
smps.Name as SDKProcessingStepName,
smps.Description as SDKProcessingStepDescription,
ptype.AssemblyName,
ptype.TypeName,
ptype.IsWorkflowActivity,
smps.Stage,
smps.AsyncAutoDelete,
smps.ComponentState,
smps.CustomizationLevel,
smpsi.entityalias,
smpsi.customizationlevel,
smpsi.imagetype,
smpsi.relatedattributename,
smpsi.MessagePropertyName,
smpsi.IsCustomizable,
smpsi.Description ImageDescription,
smpsi.IsManaged,
smpsi.Name ImageName,
smpsi.sdkmessageprocessingstepid,
smps.CreatedOn,
smf.primaryobjecttypecode,
ent.BaseTableName,
ent.LogicalName,
smps.EventHandler,
smps.EventHandlerName,
smps.EventHandlerTypeCode,
smps.IntroducedVersion,
smps.IsCustomizable,
smps.IsHidden,
smps.IsManaged,
smps.ModifiedBy,
smps.ModifiedOn,
smps.Rank,
smps.SdkMessageIdName,
smps.SolutionId,
sol.Description SolutionDescription,
smps.StateCode,
smps.StatusCode,
smps.SupportedDeployment,
smps.SupportingSolutionId,
smps.VersionNumber,
smps.SdkMessageProcessingStepId
from SdkMessageProcessingStep smps
left outer join SdkMessageProcessingStepImage smpsi on
smpsi.sdkmessageprocessingstepid = smps.SdkMessageProcessingStepId
left outer join sdkmessagefilter smf on
smf.sdkmessagefilterid = smps.sdkmessagefilterid
left outer join entity ent on
ent.objecttypecode = smf.PrimaryObjectTypeCode
left outer join SdkMessageProcessingStepSecureConfig sconfig on
sconfig.SdkMessageProcessingStepSecureConfigId = smps.SdkMessageProcessingStepSecureConfigId
left outer join PluginType ptype on
ptype.plugintypeid = smps.PluginTypeId
left outer join Solution sol on
sol.solutionid = smps.SolutionId
order by smps.Name, smps.Stage

