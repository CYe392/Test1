select 
smps.Name as SDKProcessingStepName
,smps.Description as SDKProcessingStepDescription
,ptype.AssemblyName
,ptype.TypeName
,ptype.IsWorkflowActivity
,smps.Stage
,smps.Name
,smps.Description
,smps.AsyncAutoDelete
,smps.ComponentState
,smps.CustomizationLevel
,smps.CreatedOn
,smf.primaryobjecttypecode
,ent.BaseTableName
,ent.LogicalName
,smps.EventHandler
,smps.EventHandlerName
,smps.EventHandlerTypeCode
,smps.IntroducedVersion
,smps.IsCustomizable
,smps.IsHidden
,smps.IsManaged
,smps.ModifiedBy
,smps.ModifiedOn
,smps.Rank
,smps.SdkMessageIdName
,smps.SolutionId
,smps.SdkMessageProcessingStepId
,smps.PluginTypeId
,smps.SdkMessageProcessingStepSecureConfigId
,smps.sdkmessagefilterid
,sol.Description SolutionDescription
,smps.StateCode
,smps.StatusCode
,smps.SupportedDeployment
,smps.SupportingSolutionId
,smps.VersionNumber
,smps.SdkMessageProcessingStepId
from SdkMessageProcessingStep smps
left outer join sdkmessagefilter smf on
smf.sdkmessagefilterid = smps.sdkmessagefilterid
left outer join entity ent on
ent.objecttypecode = smf.PrimaryObjectTypeCode
left outer join SdkMessageProcessingStepSecureConfig sconfig on
sconfig.SdkMessageProcessingStepSecureConfigId = smps.SdkMessageProcessingStepSecureConfigId
left outer join PluginType ptype on
ptype.plugintypeid = smps.PluginTypeId
left outer join Solution sol on
sol.solutionid = smps.SolutionId
where ltrim(rtrim(smps.Name)) != ''
order by smps.Name, smps.Stage

