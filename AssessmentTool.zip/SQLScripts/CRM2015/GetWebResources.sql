select 
pub.CustomizationPrefix,
wr.Name,
wr.WebResourceType,
wr.Description,
wr.DisplayName,
wr.IsCustomizable,
wr.IsEnabledForMobileClient,
wr.IsHidden,
wr.IsManaged,
wr.SolutionId,
wr.webresourceid,
sol.Description,
sol.FriendlyName,
sol.UniqueName,
sol.IsManaged

from WebResource wr
left outer join solution sol on
sol.SolutionId = wr.SolutionId
left outer join publisher pub on
pub.PublisherId = sol.PublisherId
order by pub.CustomizationPrefix, wr.webresourcetype, wr.DisplayName